#!/bin/bash
dir1_ayuda=$(find / -name ayuda-escaneo.txt 2>/dev/null | tr '/' ' ' | awk '{print$1}')
dir1_tiempo=$(find / -name tiempo.sh 2>/dev/null | tr '/' ' ' | awk '{print$1}')
dir1_netscan=$(find / -name escaneoenbarra24.sh 2>/dev/null | tr '/' ' ' | awk '{print$1}')
dir2_ayuda=$(find / -name ayuda-escaneo.txt 2>/dev/null | tr '/' ' ' | awk '{print$2}')
dir2_tiempo=$(find / -name tiempo.sh 2>/dev/null | tr '/' ' ' | awk '{print$2}')
dir2_netscan=$(find / -name escaneoenbarra24.sh 2>/dev/null | tr '/' ' ' | awk '{print$2}')
dir_ayuda=""$dir1_ayuda"/"$dir2_ayuda""
dir_tiempo=""$dir1_tiempo"/"$dir2_tiempo""
dir_netscan=""$dir1_netscan"/"$dir2_netscan""
echo $dir_ayuda
if [ "dir_ayuda" != "opt/netscan" ] || if [ "dir_tiempo" != "opt/netscan" ] || if [ "dir_netscan" != "opt/netscan" ] || ; then
mkdir -p /opt/netscan/bin/ayuda/
mv $netscan /opt/netscan/bin/
mv $tiempo /opt/netscan/bin/
mv $ayuda /opt/netscan/bin/ayuda/
fi

netscan=$(find / -name escaneoenbarra24.sh 2>/dev/null)
tiempo=$(find / -name tiempo.sh 2>/dev/null)
ayuda=$(find / -name ayuda-escaneo.txt 2>/dev/null)

ln -s $netscan /usr/local/bin/netscan
ln -s $tiempo /usr/local/bin/tiempo

netscan -I
